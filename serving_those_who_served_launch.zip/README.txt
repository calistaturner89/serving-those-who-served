SERVING THOSE WHO SERVED — LAUNCH PACKAGE

1. Open index.html in a browser to review the site.
2. Verify all provider names, credentials, affiliations, public descriptions and links with the organizations before public release.
3. The Suggest a Resource form currently generates copyable text. It does NOT send or store submissions. Connect a dedicated project email or form service before claiming submissions are received.
4. Publish this static index.html on a service such as GitHub Pages or Netlify. Do not include confidential information in the hosting repository.
5. Only after the public URL works should you generate a QR code for your flyer.
6. Revisit resources regularly; provider details and availability can change.

Verified reference sites (Nov 2026):
Prism directory: https://cosprismcollective.org/provider-directory/
VHTC: https://healthcircle.uccs.edu/veterans-health-and-trauma-clinic
988 Colorado: https://www.988colorado.com/en
Veterans Crisis Line: https://www.veteranscrisisline.net

The hero currently uses a designed navy gradient rather than a misleading generic mountain image. Add properly licensed Pikes Peak imagery if desired.
